const { create } = require("sourcebin");

module.exports = {
	name: "interactionCreate",
	async execute(interaction, client) {
		if (interaction.customId == "abrir-ticket") {
			await interaction.deferReply();
			if (
				client.guilds.cache
					.get(interaction.guildId)
					.channels.cache.find((c) => c.topic == interaction.user.id)
			) {
				return interaction.followUp({
					content: "Ya tenes un ticket creado!",
					ephemeral: true,
				});
			}

			interaction.guild.channels
				.create(
					`${client.config.ticketEmoji}・ticket-${interaction.user.username}`,
					{
						parent: client.config.parentOpened,
						topic: interaction.user.id,
						permissionOverwrites: [
							{
								id: interaction.user.id,
								allow: ["SEND_MESSAGES",
										"VIEW_CHANNEL",
										"READ_MESSAGE_HISTORY"],
							},
							{
								id: client.config.roleSupport,
								allow: [
									"SEND_MESSAGES",
									"VIEW_CHANNEL",
									"READ_MESSAGE_HISTORY",
								],
							},
							{
								id: interaction.guild.roles.everyone,
								deny: ["VIEW_CHANNEL"],
							},
						],
						type: "text",
					}
				)
				.then(async (c) => {
					interaction.followUp({
						content: `El ticket ha sido creado con éxito<#${c.id}>`,
						ephemeral: true,
					});

					const embed = new client.discord.MessageEmbed()
						.setColor("2f3136")
						.setDescription("**Elige una opción de ticket**")
						//.setFooter("Sistema de tickets")
						//.setTimestamp();

					const row = new client.discord.MessageActionRow().addComponents(
						new client.discord.MessageSelectMenu()
							.setCustomId("category")
							.setPlaceholder("-> Haz click aquí")
							.addOptions([
								{
									label: "Postulaciones",
									value: "Postulaciones",
									description: "Ticket unicamente para postulartes",
									emoji: "<:support:1013305174044979241>",
								},
								{
									label: "Donaciones",
									value: "Donaciones",
									description: "Ticket unicamente para donaciones",
									emoji: "<a:donador:1022627124399570985>",
								},
							])
					);

					msg = await c.send({
						content: `<@!${interaction.user.id}>`,
						embeds: [embed],
						components: [row],
					});

					const collector = msg.createMessageComponentCollector({
						componentType: "SELECT_MENU",
						time: 20000,
					});

					collector.on("collect", (i) => {
						if (i.user.id === interaction.user.id) {
							if (msg.deletable) {
								msg.delete().then(async () => {
									const embed = new client.discord.MessageEmbed()
										.setColor("2f3136")
										.setDescription(
											`<@!${interaction.user.id}> has creado un ticket con la razón ・**${i.values[0]}**`
										)	
										//.setTimestamp();

									const row =
										new client.discord.MessageActionRow().addComponents(
											new client.discord.MessageButton()
												.setCustomId("close-ticket")
												.setLabel("Cerrar ticket")
												.setEmoji("1022617345304317973")
												.setStyle("DANGER")
										);

									const opened = await c.send({
										content: `<@&${client.config.roleSupport}>`,
										embeds: [embed],
										components: [row],
									});

									opened.pin().then(() => {
										opened.channel.bulkDelete(1);
									});
								});
							}
							if (i.values[0] == "Postulaciones") {
								c.edit({
									parent: client.config.parentPostulaciones,
								});
								c.setName(
									`${client.config.nombrePostulaciones}-${interaction.user.username}`
								);
							}
							if (i.values[0] == "Donaciones") {
								c.edit({
									parent: client.config.parentDonaciones,
								});
								c.setName(
									`${client.config.nombreDonaciones}-${interaction.user.username}`
								);
							}
						}
					});

					collector.on("end", (collected) => {
						if (collected.size < 1) {
							c.send(
								`No seleccionaste ninguna opción, el ticket se cerrará`
							).then(() => {
								setTimeout(() => {
									if (c.deletable) {
										c.delete();
									}
								}, 5000);
							});
						}
					});
				});
		}

		if (interaction.customId == "close-ticket") {
			await interaction.deferReply();
			const guild = client.guilds.cache.get(interaction.guildId);
			const chan = guild.channels.cache.get(interaction.channelId);

			const row = new client.discord.MessageActionRow().addComponents(
				new client.discord.MessageButton()
					.setCustomId("cerrar-ticket")
					.setLabel("Confirmar")
					.setEmoji("1045533485969965188")
					.setStyle("SUCCESS"),
				new client.discord.MessageButton()
					.setCustomId("no")
					.setLabel("Cancelar")
					.setEmoji("1045533372908326912")
					.setStyle("DANGER")
			);
			const estas_seguro_de_cerrar_tkt = new client.discord.MessageEmbed()
				.setTitle("")
				.setDescription("¿Estás seguro de que quieres cerrar ticket?")
				.setColor("2f3136")
			await interaction.followUp({
				embeds: [estas_seguro_de_cerrar_tkt],
				components: [row],
			});
		

			const collector = interaction.channel.createMessageComponentCollector({
				componentType: "BUTTON",
				time: 10000,
			});

			collector.on("collect", (i) => {
				if (i.customId == "cerrar-ticket") {
					interaction.editReply({
						content: `El ticket ha sido cerrado por<@!${interaction.user.id}>`,
						components: [],
					});
				

					chan
						.edit({
							name: `${client.config.ticketEmojiCerrado}・closed-${chan.name}`,
							permissionOverwrites: [
								{
									id: client.users.cache.get(chan.topic),
									deny: ["SEND_MESSAGES", "VIEW_CHANNEL"],
								},
								{
									id: client.config.roleSupport,
									allow: ["SEND_MESSAGES", "VIEW_CHANNEL"],
								},
								{
									id: interaction.guild.roles.everyone,
									deny: ["VIEW_CHANNEL"],
								},
							],
						})
						.then(async () => {
							const embed = new client.discord.MessageEmbed()
								.setColor("2f3136")
								.setDescription("Ticket guardado correctamente")
								.setTimestamp();

							const row = new client.discord.MessageActionRow().addComponents(
								new client.discord.MessageButton()
									.setCustomId("borrar-ticket")
									.setLabel("Borrar ticket")
									.setEmoji("🗑️")
									.setStyle("DANGER")
							);

							chan.send({
								embeds: [embed],
								components: [row],
							});
						});

					collector.stop();
				}
			const cerradoCancelado = new client.discord.MessageEmbed()
				.setDescription("El cierre del ticket fue cancelado exitosamente")
				.setColor("2f3136")
				if (i.customId == "no") {
					interaction.editReply({
						embeds: [cerradoCancelado], //¡Cerrar el ticket fue cancelado exitosamente!
						components: [],
					});
					collector.stop();
				}
			});
				const cierre_cancelado = new client.discord.MessageEmbed()
				.setTitle("AAA")
				.setColor("2f3136")
				.setDescription("D")
			collector.on("end", (i) => {
				if (i.size < 1) {
					interaction.editReply({
						embeds: [cierre_cancelado],
						components: [],
					});
				}
			});
		}
			const guardando_tkt = new client.discord.MessageEmbed()
			.setTitle("Ticket")
			.setColor("2f3136")
			.setDescription("Su ticket fue guardado correctamente")

		if (interaction.customId == "borrar-ticket") {
			await interaction.deferReply();
			const guild = client.guilds.cache.get(interaction.guildId);
			const chan = guild.channels.cache.get(interaction.channelId);
			interaction.followUp({
				embeds: [guardando_tkt],
			});

			chan.messages.fetch().then(async (messages) => {
				let a = messages
					.filter((m) => m.author.bot !== true)
					.map(
						(m) =>
							`${new Date(m.createdTimestamp).toLocaleString("de-DE")} - ${
								m.author.username
							}#${m.author.discriminator}: ${
								m.attachments.size > 0
									? m.attachments.first().proxyURL
									: m.content
							}`
					)
					.reverse()
					.join("\n");
				if (a.length < 1) a = "No estaba escrito el ticket!";
				create({
					title: `Ticket of ${chan.topic}`,
					description: "Ticket transcripto por BloodBath Bot",
					files: [
						{
							content: a,
							language: "text",
						},
					],
				}).then(function (data) {
					const embed = new client.discord.MessageEmbed()
						.setAuthor("Logs Ticket")
						.setDescription(
							`📰 Transcript del ticket \`${chan.id}\`\n\nCreado por <@!${chan.topic}>\nCerrado por <@!${interaction.user.id}>\n\nLogs: [**Click aquí para ver el transcript**](${data.url})`
						)
						.setColor("2f3136")
						.setTimestamp();

					const embed2 = new client.discord.MessageEmbed()
						.setAuthor("Ticket")
						.setDescription(
							`📰 Transcript de su ticket \`${chan.id}\`\n\n [**Click aquí para ver su ticket**](${data.url})`
						)
						.setColor("2f3136")
						.setTimestamp();

					client.channels.cache.get(client.config.logsTicket).send({
						embeds: [embed],
					});
					client.users.cache
						.get(chan.topic)
						.send({
							embeds: [embed2],
						})
						.catch(() => {
							console.log("No puedo enviarle DM");
						});
						const embed_borrar = new client.discord.MessageEmbed()
						.setDescription("<a:reload:1044331175356928061>Borrando el canal..")
                   		.setColor("2f3136")
                    chan.send({embeds: [embed_borrar]})
					setTimeout(() => {
						chan.delete();
					}, 5000);
				});
			});
		}
	},
};
